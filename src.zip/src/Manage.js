import React from 'react';




function SignUp() {

  return (
    <div>
      <h2>USER REISTRATION WORK WILL BE HERE</h2>

    </div>
  );
}

export default SignUp;
