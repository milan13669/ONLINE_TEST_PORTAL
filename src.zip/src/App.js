import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './Home.js';
import GetAdmin from './GetAdmin';

function App() {
  return (
    <div className="App">
      {/*<GetAdmin />*/}
      <Home /> 
    </div>
  );
}

export default App;
