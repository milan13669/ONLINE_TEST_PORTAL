import React from 'react';
import { Link } from "react-router-dom";




function PersistentDrawer() {

  return (
    <div>
      <h2>USER REISTRATION WORK WILL BE HERE</h2>
      <Link class="nav-link" to="/users">
              My USERS
            </Link>
    </div>
  );
}

export default PersistentDrawer;
